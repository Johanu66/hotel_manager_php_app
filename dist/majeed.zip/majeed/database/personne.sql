-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

CREATE TABLE `personne` (
  `id_personne` int(11) NOT NULL,
  `nom_personne` text NOT NULL,
  `prenom_personne` text NOT NULL,
  `tel_personne` text NOT NULL,
  `addresse_personne` text NOT NULL,
  `email_personne` text NOT NULL,
  `nationalite_personne` text NOT NULL,
  `id_card_personne` text NOT NULL,
  `passeport_personne` text NOT NULL,
  `date_naiss_personne` date NOT NULL,
  `sexe_personne` enum('-','Masculin','Féminin') NOT NULL,
  `statut_personne` enum('Actif','Inactif') NOT NULL,
  `date_create_personne` datetime NOT NULL,
  `user_create_personne` text NOT NULL,
  `date_last_modif_personne` datetime NOT NULL,
  `user_last_modif_personne` text NOT NULL,
  `date_del_personne` datetime NOT NULL,
  `user_del_personne` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `personne`
--

INSERT INTO `personne` (`id_personne`, `nom_personne`, `prenom_personne`, `tel_personne`, `addresse_personne`, `email_personne`, `nationalite_personne`, `id_card_personne`, `passeport_personne`, `date_naiss_personne`, `sexe_personne`, `statut_personne`, `date_create_personne`, `user_create_personne`, `date_last_modif_personne`, `user_last_modif_personne`, `date_del_personne`, `user_del_personne`) VALUES
(1, 'ALIDOU', 'Abdou Majeed', '', '', '', '', '', '', '0000-00-00', 'Masculin', 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 'DOE', 'John', '', '', '', '', '', '', '0000-00-00', 'Féminin', 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(5, 'SATIL', 'Johnson', '43344334', '', 'someone@something.com', '', '', '', '0000-00-00', 'Masculin', 'Actif', '2021-06-12 23:57:32', 'Abdou Majeed ALIDOU', '2021-06-12 23:57:32', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(6, 'Joachim', 'NOH', '32', '', '', '', '', '', '0000-00-00', 'Masculin', 'Actif', '2021-06-13 23:57:04', 'Abdou Majeed ALIDOU', '2021-06-13 23:57:04', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(7, 'ab', 'b', '2', '', '', '', '', '', '0000-00-00', '-', 'Actif', '2021-06-16 13:25:10', 'Abdou Majeed ALIDOU', '2021-06-16 13:25:10', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(8, 'g', 'j', '13', '', '', '', '', '', '0000-00-00', '-', 'Actif', '2021-06-16 13:56:40', 'Abdou Majeed ALIDOU', '2021-06-16 13:56:40', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `personne`
--
ALTER TABLE `personne`
  ADD PRIMARY KEY (`id_personne`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `personne`
--
ALTER TABLE `personne`
  MODIFY `id_personne` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
