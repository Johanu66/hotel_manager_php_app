-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `facture_conf`
--

CREATE TABLE `facture_conf` (
  `id_facture_conf` int(11) NOT NULL,
  `num_facture_conf` text NOT NULL,
  `date_facture_conf` datetime NOT NULL,
  `methode_paiement_facture_conf` text NOT NULL,
  `tva_facture_conf` enum('Oui','Non') NOT NULL,
  `valeur_tva_facture_conf` double NOT NULL,
  `montant_ht_facture_conf` double NOT NULL,
  `montant_ttc_facture_conf` double NOT NULL,
  `montant_ttc_en_lettre_facture_conf` text NOT NULL,
  `statut_facture_conf` enum('Actif','Annulé') NOT NULL,
  `date_create_facture_conf` datetime NOT NULL,
  `user_create_facture_conf` text NOT NULL,
  `date_last_modif_facture_conf` datetime NOT NULL,
  `user_last_modif_facture_conf` text NOT NULL,
  `date_del_facture_conf` datetime NOT NULL,
  `user_del_facture_conf` text NOT NULL,
  `id_location_conf_fk_facture_conf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `facture_conf`
--

INSERT INTO `facture_conf` (`id_facture_conf`, `num_facture_conf`, `date_facture_conf`, `methode_paiement_facture_conf`, `tva_facture_conf`, `valeur_tva_facture_conf`, `montant_ht_facture_conf`, `montant_ttc_facture_conf`, `montant_ttc_en_lettre_facture_conf`, `statut_facture_conf`, `date_create_facture_conf`, `user_create_facture_conf`, `date_last_modif_facture_conf`, `user_last_modif_facture_conf`, `date_del_facture_conf`, `user_del_facture_conf`, `id_location_conf_fk_facture_conf`) VALUES
(5, '43e', '2021-06-12 11:05:00', 'de', 'Oui', 2.4, 25000, 25600, 'vingt cinq mille six cent', 'Annulé', '2021-06-17 12:05:17', 'Abdou Majeed ALIDOU', '2021-06-17 12:05:17', 'Abdou Majeed ALIDOU', '2021-06-28 14:49:19', 'Abdou Majeed ALIDOU', 6),
(6, 'r', '2021-06-12 11:05:00', 'rr4', 'Non', 0, 120000, 120000, 'Cent vingt mille', 'Annulé', '2021-06-17 12:05:55', 'Abdou Majeed ALIDOU', '2021-06-17 12:05:55', 'Abdou Majeed ALIDOU', '2021-06-28 10:40:09', 'Abdou Majeed ALIDOU', 1),
(7, '3ee3r4', '2021-06-25 16:12:00', 'visa', 'Non', 0, 35000, 35000, 'Trente cinq mille', 'Actif', '2021-06-17 17:12:18', 'Abdou Majeed ALIDOU', '2021-06-17 17:12:18', 'Abdou Majeed ALIDOU', '2021-06-29 13:07:07', 'Abdou Majeed ALIDOU', 18);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `facture_conf`
--
ALTER TABLE `facture_conf`
  ADD PRIMARY KEY (`id_facture_conf`),
  ADD KEY `id_location_conf_fk_facture_conf` (`id_location_conf_fk_facture_conf`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `facture_conf`
--
ALTER TABLE `facture_conf`
  MODIFY `id_facture_conf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `facture_conf`
--
ALTER TABLE `facture_conf`
  ADD CONSTRAINT `Rel Location Conf et Facture Conf` FOREIGN KEY (`id_location_conf_fk_facture_conf`) REFERENCES `location_conf` (`id_location_conf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
