-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `assoc_salle_conf_and_carac_conf`
--

CREATE TABLE `assoc_salle_conf_and_carac_conf` (
  `id_salle_conf_fk_assoc_salle_conf_and_carac_conf` int(11) NOT NULL,
  `id_carac_conf_fk_assoc_salle_conf_and_carac_conf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `assoc_salle_conf_and_carac_conf`
--

INSERT INTO `assoc_salle_conf_and_carac_conf` (`id_salle_conf_fk_assoc_salle_conf_and_carac_conf`, `id_carac_conf_fk_assoc_salle_conf_and_carac_conf`) VALUES
(11, 1),
(11, 10),
(16, 10),
(16, 11);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `assoc_salle_conf_and_carac_conf`
--
ALTER TABLE `assoc_salle_conf_and_carac_conf`
  ADD PRIMARY KEY (`id_salle_conf_fk_assoc_salle_conf_and_carac_conf`,`id_carac_conf_fk_assoc_salle_conf_and_carac_conf`),
  ADD KEY `id_salle_conf_fk_assoc_salle_conf_and_carac_conf` (`id_salle_conf_fk_assoc_salle_conf_and_carac_conf`,`id_carac_conf_fk_assoc_salle_conf_and_carac_conf`),
  ADD KEY `Rel Carac Conf et Assoc` (`id_carac_conf_fk_assoc_salle_conf_and_carac_conf`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `assoc_salle_conf_and_carac_conf`
--
ALTER TABLE `assoc_salle_conf_and_carac_conf`
  ADD CONSTRAINT `Rel Carac Conf et Assoc` FOREIGN KEY (`id_carac_conf_fk_assoc_salle_conf_and_carac_conf`) REFERENCES `carac_conf` (`id_carac_conf`),
  ADD CONSTRAINT `Rel Salle Conf et Assoc` FOREIGN KEY (`id_salle_conf_fk_assoc_salle_conf_and_carac_conf`) REFERENCES `salle_conf` (`id_salle_conf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
