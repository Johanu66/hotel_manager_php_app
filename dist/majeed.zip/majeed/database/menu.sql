-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `lib_menu` text NOT NULL,
  `statut_menu` enum('Actif','Inactif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `menu`
--

INSERT INTO `menu` (`id_menu`, `lib_menu`, `statut_menu`) VALUES
(1, 'type_chambre', 'Actif'),
(2, 'chambre', 'Actif'),
(3, 'carac_chambre', 'Actif'),
(4, 'reserv_dispo', 'Actif'),
(5, 'reserv_attente', 'Actif'),
(6, 'reserv_confirme', 'Actif'),
(7, 'reserv_termine', 'Actif'),
(8, 'reserv_annule', 'Actif'),
(9, 'carac_conf', 'Actif'),
(10, 'service_conf', 'Actif'),
(11, 'salle_conf', 'Actif'),
(12, 'article_restau', 'Actif'),
(13, 'plat', 'Actif'),
(14, 'type_plat', 'Actif'),
(15, 'marque_voiture', 'Actif'),
(16, 'voiture', 'Actif'),
(17, 'boisson', 'Actif'),
(18, 'location_conf', 'Actif'),
(19, 'facture_conf', 'Actif'),
(20, 'location_voiture', 'Actif'),
(21, 'facture_voiture', 'Actif'),
(22, 'stat_conf', 'Actif');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
