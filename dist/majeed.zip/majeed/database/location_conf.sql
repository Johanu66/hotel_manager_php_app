-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `location_conf`
--

CREATE TABLE `location_conf` (
  `id_location_conf` int(11) NOT NULL,
  `date_debut_location_conf` datetime NOT NULL,
  `date_fin_location_conf` datetime NOT NULL,
  `motif_location_conf` text NOT NULL,
  `facture_location_conf` enum('Non','Oui','Annulé') NOT NULL,
  `prix_location_conf` double DEFAULT NULL,
  `statut_location_conf` enum('Actif','Inactif') NOT NULL,
  `date_create_location_conf` datetime NOT NULL,
  `user_create_location_conf` text NOT NULL,
  `date_last_modif_location_conf` datetime NOT NULL,
  `user_last_modif_location_conf` text NOT NULL,
  `date_del_location_conf` datetime NOT NULL,
  `user_del_location_conf` text NOT NULL,
  `id_salle_conf_fk_location_conf` int(11) NOT NULL,
  `id_client_fk_location_conf` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `location_conf`
--

INSERT INTO `location_conf` (`id_location_conf`, `date_debut_location_conf`, `date_fin_location_conf`, `motif_location_conf`, `facture_location_conf`, `prix_location_conf`, `statut_location_conf`, `date_create_location_conf`, `user_create_location_conf`, `date_last_modif_location_conf`, `user_last_modif_location_conf`, `date_del_location_conf`, `user_del_location_conf`, `id_salle_conf_fk_location_conf`, `id_client_fk_location_conf`) VALUES
(1, '2021-06-14 08:00:00', '2021-06-18 18:00:00', 'Ecologie', 'Annulé', 120000, 'Actif', '2021-06-13 20:09:20', 'Abdou Majeed ALIDOU', '2021-06-17 12:05:55', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '', 15, 50),
(2, '2021-06-26 09:00:00', '2021-06-29 09:00:00', '12', 'Non', 12, 'Inactif', '2021-06-13 23:57:05', 'Abdou Majeed ALIDOU', '2021-06-15 15:09:01', 'Abdou Majeed ALIDOU', '2021-06-15 16:39:27', 'Abdou Majeed ALIDOU', 16, 50),
(5, '2021-08-14 14:56:00', '2021-08-15 14:56:00', '', 'Non', 0, 'Inactif', '2021-06-14 15:56:32', 'Abdou Majeed ALIDOU', '2021-06-15 10:25:07', 'Abdou Majeed ALIDOU', '2021-06-15 16:38:50', 'Abdou Majeed ALIDOU', 13, 50),
(6, '2021-06-01 07:00:00', '2021-06-02 17:30:00', 'Javascript', 'Annulé', 25000, 'Actif', '2021-06-15 16:36:23', 'Abdou Majeed ALIDOU', '2021-06-17 12:05:18', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '', 15, 54),
(9, '2021-06-29 10:57:00', '2021-06-30 10:57:00', '', 'Non', 0, 'Inactif', '2021-06-16 11:59:37', 'Abdou Majeed ALIDOU', '2021-06-16 13:32:43', 'Abdou Majeed ALIDOU', '2021-06-16 13:32:50', 'Abdou Majeed ALIDOU', 16, 54),
(11, '2021-06-23 13:50:00', '2021-06-23 14:48:00', 'test', 'Non', 0, 'Inactif', '2021-06-16 13:49:30', 'Abdou Majeed ALIDOU', '2021-06-17 12:04:03', 'Abdou Majeed ALIDOU', '2021-06-17 13:56:01', 'Abdou Majeed ALIDOU', 13, 54),
(12, '2021-06-10 12:55:00', '2021-06-11 07:56:00', '', 'Non', 0, 'Inactif', '2021-06-16 13:56:41', 'Abdou Majeed ALIDOU', '2021-06-16 13:56:41', 'Abdou Majeed ALIDOU', '2021-06-16 14:17:22', 'Abdou Majeed ALIDOU', 16, 56),
(13, '2021-06-05 12:08:00', '2021-06-06 12:08:00', '', 'Non', 0, 'Inactif', '2021-06-17 13:09:08', 'Abdou Majeed ALIDOU', '2021-06-17 13:09:08', 'Abdou Majeed ALIDOU', '2021-06-17 13:56:14', 'Abdou Majeed ALIDOU', 16, 50),
(14, '2021-06-01 12:17:00', '2021-06-02 12:17:00', '', 'Non', 0, 'Inactif', '2021-06-17 13:17:39', 'Abdou Majeed ALIDOU', '2021-06-17 13:17:39', 'Abdou Majeed ALIDOU', '2021-06-17 13:56:10', 'Abdou Majeed ALIDOU', 12, 53),
(15, '2021-06-02 12:20:00', '2021-06-03 12:20:00', '', 'Non', NULL, 'Inactif', '2021-06-17 13:20:20', 'Abdou Majeed ALIDOU', '2021-06-17 13:20:20', 'Abdou Majeed ALIDOU', '2021-06-17 13:56:05', 'Abdou Majeed ALIDOU', 12, 54),
(16, '2021-06-01 05:20:00', '2021-06-04 12:20:00', '', 'Non', NULL, 'Inactif', '2021-06-17 13:21:30', 'Abdou Majeed ALIDOU', '2021-06-17 13:52:00', 'Abdou Majeed ALIDOU', '2021-06-17 13:55:55', 'Abdou Majeed ALIDOU', 12, 56),
(17, '2021-06-06 12:24:00', '2021-06-07 12:24:00', '', 'Non', NULL, 'Inactif', '2021-06-17 13:24:53', 'Abdou Majeed ALIDOU', '2021-06-17 13:24:53', 'Abdou Majeed ALIDOU', '2021-06-17 13:55:49', 'Abdou Majeed ALIDOU', 16, 56),
(18, '2021-06-29 13:16:00', '2021-06-30 13:16:00', '', 'Annulé', 35000, 'Actif', '2021-06-17 14:17:07', 'Abdou Majeed ALIDOU', '2021-06-17 17:12:18', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '', 13, 53),
(19, '2021-06-12 15:41:00', '2021-06-13 15:41:00', '', 'Non', 12000, 'Inactif', '2021-06-17 16:41:36', 'Abdou Majeed ALIDOU', '2021-06-17 16:41:36', 'Abdou Majeed ALIDOU', '2021-06-29 10:30:21', 'Abdou Majeed ALIDOU', 13, 50),
(20, '2021-06-12 09:07:00', '2021-06-17 07:07:00', 'top', 'Non', 350000, 'Actif', '2021-06-29 10:08:34', 'Abdou Majeed ALIDOU', '2021-06-29 11:31:20', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '', 16, 54),
(21, '2021-07-02 10:32:00', '2021-07-03 10:32:00', 'Na', 'Non', NULL, 'Actif', '2021-06-29 11:32:51', 'Abdou Majeed ALIDOU', '2021-06-29 11:33:02', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '', 12, 53);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `location_conf`
--
ALTER TABLE `location_conf`
  ADD PRIMARY KEY (`id_location_conf`),
  ADD KEY `id_salle_conf_fk_location_conf` (`id_salle_conf_fk_location_conf`),
  ADD KEY `id_client_fk_location_conf` (`id_client_fk_location_conf`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `location_conf`
--
ALTER TABLE `location_conf`
  MODIFY `id_location_conf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `location_conf`
--
ALTER TABLE `location_conf`
  ADD CONSTRAINT `Rel Location Conf et Client` FOREIGN KEY (`id_client_fk_location_conf`) REFERENCES `client` (`id_client`),
  ADD CONSTRAINT `Rel Location Conf et Salle Conf` FOREIGN KEY (`id_salle_conf_fk_location_conf`) REFERENCES `salle_conf` (`id_salle_conf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
