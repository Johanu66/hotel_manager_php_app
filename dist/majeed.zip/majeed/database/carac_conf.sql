-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `carac_conf`
--

CREATE TABLE `carac_conf` (
  `id_carac_conf` int(11) NOT NULL,
  `nom_carac_conf` text NOT NULL,
  `desc_carac_conf` text NOT NULL,
  `statut_carac_conf` enum('Actif','Inactif') NOT NULL,
  `date_create_carac_conf` datetime NOT NULL,
  `user_create_carac_conf` text NOT NULL,
  `date_last_modif_carac_conf` datetime NOT NULL,
  `user_last_modif_carac_conf` text NOT NULL,
  `date_del_carac_conf` datetime NOT NULL,
  `user_del_carac_conf` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `carac_conf`
--

INSERT INTO `carac_conf` (`id_carac_conf`, `nom_carac_conf`, `desc_carac_conf`, `statut_carac_conf`, `date_create_carac_conf`, `user_create_carac_conf`, `date_last_modif_carac_conf`, `user_last_modif_carac_conf`, `date_del_carac_conf`, `user_del_carac_conf`) VALUES
(1, 'Climatisé', 'Très Froid', 'Actif', '0000-00-00 00:00:00', '', '2021-06-04 16:54:48', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(9, 'Tables rondes', '10 personnes', 'Actif', '2021-06-04 17:42:47', 'Abdou Majeed ALIDOU', '2021-06-07 01:57:32', 'Abdou Majeed ALIDOU', '2021-06-04 17:44:31', 'Abdou Majeed ALIDOU'),
(10, 'Micro', 'Avec Hauts-parleurs', 'Actif', '2021-06-07 02:03:31', 'Abdou Majeed ALIDOU', '2021-06-07 02:03:31', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(11, 'Podium', '', 'Actif', '2021-06-07 02:08:04', 'Abdou Majeed ALIDOU', '2021-06-07 02:08:04', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `carac_conf`
--
ALTER TABLE `carac_conf`
  ADD PRIMARY KEY (`id_carac_conf`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `carac_conf`
--
ALTER TABLE `carac_conf`
  MODIFY `id_carac_conf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
