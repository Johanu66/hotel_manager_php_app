-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `salle_conf`
--

CREATE TABLE `salle_conf` (
  `id_salle_conf` int(11) NOT NULL,
  `nom_salle_conf` text NOT NULL,
  `desc_salle_conf` text NOT NULL,
  `capacite_salle_conf` text NOT NULL,
  `statut_salle_conf` enum('Actif','Inactif') NOT NULL,
  `date_create_salle_conf` datetime NOT NULL,
  `user_create_salle_conf` text NOT NULL,
  `date_last_modif_salle_conf` datetime NOT NULL,
  `user_last_modif_salle_conf` text NOT NULL,
  `date_del_salle_conf` datetime NOT NULL,
  `user_del_salle_conf` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `salle_conf`
--

INSERT INTO `salle_conf` (`id_salle_conf`, `nom_salle_conf`, `desc_salle_conf`, `capacite_salle_conf`, `statut_salle_conf`, `date_create_salle_conf`, `user_create_salle_conf`, `date_last_modif_salle_conf`, `user_last_modif_salle_conf`, `date_del_salle_conf`, `user_del_salle_conf`) VALUES
(11, 'Small', 'Pour les petites réunions', '16 personnes', 'Actif', '2021-06-07 01:59:56', 'Abdou Majeed ALIDOU', '2021-06-14 00:42:34', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(12, 'Medium', '', '60 personnes', 'Actif', '2021-06-07 02:01:44', 'Abdou Majeed ALIDOU', '2021-06-07 02:01:44', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(13, 'Large', 'Conférences, etc', '200', 'Actif', '2021-06-07 02:03:03', 'Abdou Majeed ALIDOU', '2021-06-07 02:03:03', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', ''),
(15, 'Xtra', 'Le top du top', '3000+', 'Actif', '2021-06-07 02:09:40', 'Abdou Majeed ALIDOU', '2021-06-07 02:09:40', 'Abdou Majeed ALIDOU', '2021-06-17 13:58:51', 'Abdou Majeed ALIDOU'),
(16, 'Futur', 'Plein air', '6000', 'Actif', '2021-06-07 09:36:45', 'Abdou Majeed ALIDOU', '2021-06-17 13:58:24', 'Abdou Majeed ALIDOU', '0000-00-00 00:00:00', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `salle_conf`
--
ALTER TABLE `salle_conf`
  ADD PRIMARY KEY (`id_salle_conf`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `salle_conf`
--
ALTER TABLE `salle_conf`
  MODIFY `id_salle_conf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
