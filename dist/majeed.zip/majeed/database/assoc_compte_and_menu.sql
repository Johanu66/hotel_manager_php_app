-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 juin 2021 à 16:42
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `assoc_compte_and_menu`
--

CREATE TABLE `assoc_compte_and_menu` (
  `id_compte_fk_assoc_compte_and_menu` int(11) NOT NULL,
  `id_menu_fk_assoc_compte_and_menu` int(11) NOT NULL,
  `statut_assoc_compte_and_menu` enum('Inactif','Actif') NOT NULL,
  `date_create_assoc_compte_and_menu` datetime NOT NULL,
  `user_create_assoc_compte_and_menu` text NOT NULL,
  `date_last_modif_assoc_compte_and_menu` datetime NOT NULL,
  `user_last_modif_assoc_compte_and_menu` text NOT NULL,
  `date_del_assoc_compte_and_menu` datetime NOT NULL,
  `user_del_assoc_compte_and_menu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `assoc_compte_and_menu`
--

INSERT INTO `assoc_compte_and_menu` (`id_compte_fk_assoc_compte_and_menu`, `id_menu_fk_assoc_compte_and_menu`, `statut_assoc_compte_and_menu`, `date_create_assoc_compte_and_menu`, `user_create_assoc_compte_and_menu`, `date_last_modif_assoc_compte_and_menu`, `user_last_modif_assoc_compte_and_menu`, `date_del_assoc_compte_and_menu`, `user_del_assoc_compte_and_menu`) VALUES
(1, 1, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 2, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 3, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 4, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 5, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 6, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 7, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 8, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 9, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 10, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 11, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 12, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 13, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 14, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 15, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 16, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 17, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 18, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 19, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 20, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 21, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(1, 22, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 1, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 2, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 3, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 4, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 5, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 6, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 7, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 8, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 9, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 10, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 11, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 12, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 13, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 14, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 15, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 16, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 17, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 18, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 19, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 22, 'Actif', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `assoc_compte_and_menu`
--
ALTER TABLE `assoc_compte_and_menu`
  ADD PRIMARY KEY (`id_compte_fk_assoc_compte_and_menu`,`id_menu_fk_assoc_compte_and_menu`),
  ADD KEY `id_compte_fk_assoc_compte_and_menu` (`id_compte_fk_assoc_compte_and_menu`,`id_menu_fk_assoc_compte_and_menu`),
  ADD KEY `Rel Menu et Assoc` (`id_menu_fk_assoc_compte_and_menu`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `assoc_compte_and_menu`
--
ALTER TABLE `assoc_compte_and_menu`
  ADD CONSTRAINT `Rel Compte et Assoc` FOREIGN KEY (`id_compte_fk_assoc_compte_and_menu`) REFERENCES `compte` (`id_compte`),
  ADD CONSTRAINT `Rel Menu et Assoc` FOREIGN KEY (`id_menu_fk_assoc_compte_and_menu`) REFERENCES `menu` (`id_menu`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
