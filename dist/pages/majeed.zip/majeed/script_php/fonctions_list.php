<?php

function fill_type_chambre_list($connect)
{
    $query = "
	SELECT * FROM type_chambre 
	WHERE statut_type_chambre = 'Actif' 
	ORDER BY nom_type_chambre ASC 
	";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_type_chambre"].'">'.$row["nom_type_chambre"].'</option>';
    }
    return $output;
}

function fill_client_list($connect)
{
    $query = "
	SELECT id_client, nom_personne, prenom_personne
    FROM client, personne
    WHERE personne.id_personne = client.id_personne_fk_client 
	ORDER BY nom_personne ASC 
	";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_client"].'">'.$row["nom_personne"]. ' '. $row["prenom_personne"] . '</option>';
    }
    return $output;
}

function fill_type_plat_list($connect)
{
    $query = "
    SELECT * FROM type_plat 
    WHERE statut_type_plat = 'Actif' 
    ORDER BY nom_type_plat ASC 
    ";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_type_plat"].'">'.$row["nom_type_plat"].'</option>';
    }
    return $output;
}

function fill_salle_conf_list($connect)
{
    $query = "
    SELECT * FROM salle_conf 
    WHERE statut_salle_conf = 'Actif' 
    ORDER BY nom_salle_conf ASC 
    ";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_salle_conf"].'">'.$row["nom_salle_conf"].'</option>';
    }
    return $output;
}

function fill_marque_voiture_list($connect)
{
    $query = "
    SELECT * FROM marque_voiture 
    WHERE statut_marque_voiture = 'Actif' 
    ORDER BY nom_marque_voiture ASC 
    ";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_marque_voiture"].'">'.$row["nom_marque_voiture"].'</option>';
    }
    return $output;
}


function fill_carac_salle_list($connect)
{
    $query = "SELECT id_carac_conf, nom_carac_conf FROM carac_conf
    WHERE statut_carac_conf = 'Actif'
    ORDER BY nom_carac_conf ASC
	";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_carac_conf"].'">'. $row["nom_carac_conf"] .'</option>';
    }
    return $output;
}


function fill_service_conf_list($connect)
{
    $query = "SELECT * FROM service_conf
    WHERE statut_service_conf = 'Actif'
    ORDER BY nom_service_conf ASC
	";
    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $output = '';
    foreach($result as $row)
    {
        $output .= '<option value="'.$row["id_service_conf"].'">'. $row["nom_service_conf"] .'</option>';
    }
    return $output;
}


function count_reserv_attente($connect)
{
	$statement = $connect->prepare("
    SELECT id_reservation, date_debut_reservation, date_fin_reservation, nom_type_chambre, nom_chambre, nom_client, prenom_client, tarif_montant_chambre_reservee, statut_reservation
    FROM reservation, client, chambre_reservee, type_chambre, chambre
    WHERE reservation.id_client_fk_reservation = client.id_client
    AND chambre_reservee.id_chambre_fk_chambre_reservee = chambre.id_chambre
    AND chambre_reservee.id_reservation_fk_chambre_reservee = reservation.id_reservation
    AND chambre.id_type_chambre_fk_chambre = type_chambre.id_type_chambre
    AND statut_reservation = 'En attente' 
    ");
	$statement->execute();
	return $statement->rowCount();
}



